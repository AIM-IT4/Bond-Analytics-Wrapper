
import BondAnalytics

bond = BondAnalytics.BondAnalytics()
clean_price = bond.clean_price(1000, 0.05, 0.04, 5)
print("Clean Price:", clean_price)
