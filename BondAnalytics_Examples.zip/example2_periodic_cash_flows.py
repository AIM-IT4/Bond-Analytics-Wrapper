
import BondAnalytics

bond = BondAnalytics.BondAnalytics()
cash_flows = bond.periodic_cash_flows(5, 1000, 0.05)
print("Periodic Cash Flows:", cash_flows)
